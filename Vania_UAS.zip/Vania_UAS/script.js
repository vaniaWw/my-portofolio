document.querySelector("#contact form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Message sent!");
  e.target.reset();
});
